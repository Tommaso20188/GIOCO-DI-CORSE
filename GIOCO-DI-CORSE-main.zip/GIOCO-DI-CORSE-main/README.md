"C:\Users\tomma\Desktop\gioco_corse"
